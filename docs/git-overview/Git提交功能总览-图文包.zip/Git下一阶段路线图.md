# 开发文档-074 · Git 下一阶段路线图（对评审意见的回应）

> 输入：用户给的 PyCharm 2026.2 工作流对照评审（P0/P1/P2 表 + 13 条建议 + 五阶段排序）。
> 配套：`docs/开发文档-073-Git提交功能总览.md`（现状）、`docs/待办-提交窗口剩余项.md`（已列未做项）。
> 本文只做两件事：**用代码事实校正评审里的判断**，然后给出**我认为该走的顺序**。

## 0. 一句话

评审的方向**大方向我同意**（提交模型、后端、分支工作流是真的欠账），
但里面两条最关键的"问题描述"**与当前代码不符** —— 如果照那个描述开工，会先做一个不需要做的重构。
先把事实摆出来，再谈顺序。

## 1. 事实校正（都带代码位置）

### ① 「勾选 = 实际操作 Git Index」——不成立（但结论仍然成立，只是位置不同）

| 步骤 | 实际发生了什么 | 位置 |
|---|---|---|
| 点复选框 | **只改内存里的 `checked` Set** + 刷 UI，**不碰 index** | `renderer/git-panel.js:843-847` |
| 点提交 | 才拿这个集合去反推 index：不在集合里、且 index 与 HEAD 不一致的文件 → `resetIndex`（取消暂存）；集合里的文件 → `git add {force:true}` / `git remove` | `git-service.js:306-313`、`:319` |

也就是说**"提交选择"这一层其实已经存在**（内存 Set + 提交时一次性物化），不是"两件事混成一件"。
真正的问题有三个，比评审说的更具体、也更好修：

1. **不持久**：Set 在内存里，刷新/重开就回到"全不勾"。Changelist 缺的是**命名 + 落盘**（`.myide/changelists.json`），不是解耦。
2. **提交时会把别人暂存的内容 unstage**：你在终端 `git add` 过、或者上一次用 IDE 之外工具暂存过的东西，
   只要这次没勾，提交时会被 IDE **顺手取消暂存**（`:306-313` 那个循环）。
   这是"IDE 把 index 当成自己的草稿区"的直接后果 —— 评审担心的"混在一起"体现在这里，**这条要修**。
3. **没有子文件粒度**：`checked` 的粒度是 "文件路径"，没有任何 hunk/行 概念。

→ 结论：**别做"把 Index 和选择分离"的重构**（已经分开了）；要做的是
「Changelist（持久化 + 命名）+ 不动别人的暂存 + 子文件粒度」。工作量比评审估计的小一大截，收益一样。

### ② 「IDE 自己维护密码」——已经接了系统凭证，且**已经在 spawn 原生 git**

- `git-service.js:940-960` `systemCredentialFill(url)` → `execFile('git', ['credential','fill'])`：
  **已经直接用 Git Credential Helper**（命令行存过的凭证可复用），结果按 `protocol//host` 进程内缓存。
- `git-service.js:884` → `execFile('git', ['-C', root, 'config','--get-urlmatch','http.proxy', url])`：代理也是问原生 git。
- 按主机存的 `myide-git-auth-map` 只是**没有 helper 的主机**的兜底 UI（多台 Git 服务器场景）。

→ 结论：**"接 Credential Helper"不是新功能，是已有能力**；要做的是「凭证优先级 UI 化」
（显示 GitHub ✓ 已认证 / 来源是 Credential Manager 还是 IDE 兜底 / 冲突时怎么选），而不是推倒重来。
另外这条也说明：**原生 git 早就不是"要不要引入"的问题了，`execFile('git', ...)` 已经在跑** ——
评审 P0 的 Native Backend 是"把已经在跑的东西**正规化**"，而不是从零引依赖。

### ③ 其余核对

| 评审说法 | 事实 |
|---|---|
| Pull 只有 fetch + fast-forward | ✅ 对，`git-service.js:1147` `fastForwardOnly: true`；分叉时文案把用户推给命令行 |
| 没有 stash | ✅ 对，全仓库 `stash` 只出现在一句注释里（`git-service.js:1435` 「不依赖 git stash」） |
| Shelve 自造存储 | ✅ 对，内容 base64 存 `<repo>/.git/myide-shelves/` |
| 没有 git 可执行文件路径配置 | ✅ 对，设置页 Git 分类只有 user.name / user.email（`renderer/settings.js:381-400`） |
| 没有 merge / rebase / hooks / add -p | ✅ 对（isomorphic-git 无这些能力） |
| 我自己的 073 文档写"**没有 credential helper**" | ❌ **我那句写错了**，见 ②；已在 073 里改掉 |

## 2. 逐条表态

| 评审建议 | 我的态度 |
|---|---|
| Native Git CLI Backend | **同意，但按"正规化"做**：`git -C <root> ...` 已有两处调用，先抽成 `GitBackend` 接口 + 能力探测，**只把 merge/rebase/stash/hooks/credential 迁过去**，现有 38 个通道行为不动 |
| Commit Selection 与 Index 分离 | **部分同意**：分离已有，改成「持久化 + 不误 unstage 别人的暂存 + 子文件粒度」 |
| Changelist | **同意，且建议第一个做**（纯客户端概念，零 Git 风险，用户可感知最强） |
| hunk / 行级部分提交 | **同意**，但要排在 Backend 之后（native `git apply --cached` 比自研 patch 稳得多） |
| Merge / Rebase / 冲突解决器 | **同意**，这是"像 IDE"和"真的能用"的分界线 |
| 分支弹窗升级成分支操作中心 | **同意**（本地/远程、upstream、compare、merge/rebase 入口） |
| Pull 支持 Merge / Rebase / FF-only | **同意**（顺带把"分叉就把用户推去命令行"的文案干掉） |
| 接 Git Credential Helper | **已在做**，改成「优先级 + 状态 UI 化」 |
| Shelf 与 Stash 分开 | **同意概念，不同意现在拆**：先加 `git stash` 作为一等公民（apply/pop/drop/keep-index/include-untracked），Shelf 保留并加「导出/导入 patch」，两者在 UI 上明确标注来源，不重写已有稳定的 Shelve |
| Before Commit | **同意**，且建议**和 Hooks 一起做**（同一套"提交前跑命令 + 结果面板"） |
| Git Log 加 Branches Pane | **同意**（三栏：Branches ｜ Commits ｜ Changes / Commit Detail） |
| Local History | **同意，且我认为它在本项目里优先级比评审给的更高** —— 见 §3 |
| Multi-root / Worktree / Submodule | **同意放最后** |
| 视觉：工具行收 `⋮ More`、<400px 自动走编辑区 diff | **同意**，但先别急：这个是"等新功能进来之后再做"的收纳动作，现在做等于白做一遍 |

**我明确反对的一条**：评审末尾自己也点了 —— 不要做 `git.exec(任意字符串)` 这种通用通道。
白名单操作（`git.branch.merge(...)`）必须保留，registry 只是省掉"手抄三遍接口定义"。

## 3. 我的额外一条：Local History × AI checkpoint

评审把 Local History 放 P1，我认为应该**提前到提交模型之后**，理由是本项目有 AI 改代码：

- 触发点天然存在：**AI 每次写文件前自动打一个 checkpoint**（现在 AI 已经在写文件了，加一个快照钩子成本极低）。
- 存储：`.myide/history/<路径哈希>/<时间戳>.snap` + 一个 `index.json`（含触发原因：编辑 / AI / 重构 / 运行配置）。
- UI 复用现有 diff 视图（`GitPanel.renderDiffView` 已是通用渲染器）。
- 价值：**"AI 改坏了 → 一键回到那一步"**，这是 Git 给不了的（未提交的内容 Git 管不到），
  而 AI 大量改写文件恰恰让这个能力变成刚需。

## 4. 我建议的顺序（5 个里程碑）

每一步都能独立验收、独立回滚。

### M1 · Changelist v1（纯客户端，零 Git 风险）
> ✅ **已完成**（2026-09-23）：见 `docs/开发文档-075-M1-提交模型（Changelist与暂存区解耦）.md`。
> 实际落地比这份草案多了「提交事务」（读 index 原件 → 临时改 → 提交 → 原样写回）+「已暂存（外部）」只读分节。
- 数据：`.myide/changelists.json`（与 `tasks.json` 同源同思路：随项目走，写失败降级 localStorage）
- 渲染：活动列表正常渲染可勾选；其它列表折叠成 `▸ 列表名 N 个文件`（**不可勾选**，避免"勾了却不提交"的误导）
- 操作：右键「移入变更列表…」、`F6`；文件不属于任何列表 = 属于 `Default`
- 同时修：提交时**不再 unstage** 未被选中但 index 与 HEAD 不一致的文件
  （改成：只 unstage "本次勾选集合里被反选过的"，其余保持原样，并在 UI 上提示"检测到暂存内容"）
- 验收：新增自检步骤 + dom 用例；`--check-ui` 全绿

### M2 · GitBackend 抽象 + 能力探测（行为不变）
> ✅ **已完成**（2026-09-23）：见 `docs/开发文档-076-M2-原生Git后端与能力路由.md`。
> 按用户拍板改名「**按能力路由**」：已稳定的 status/log/diff/commit/branch **留在 isomorphic 不动**，
> 只把 credential / proxy 收编进 `git-native.js`；设置页可配 git 可执行文件；`git-ops.js` 成为 IPC 唯一清单
> （preload / mock 不自动生成 —— `sandbox:true` 禁 require 本地模块 —— 改成**漂移检查**，一上线就抓出 mock 缺 `cherryPick`）。
- `git-service.js` → `backends/{native,isomorphic}.js`，`GitBackend` 接口；`execFile('git', ...)` 收口
- 新增 `backend.info`（版本、能力位：`merge/rebase/stash/hooks/apply-cached`）
- 设置页加「Git 可执行文件」路径（默认 `git`，可指定，如 WSL）
- **只迁** merge / rebase / stash / hooks / apply-cached；其余留在 isomorphic，行为零变化
- 验收：现有 38 通道全绿 + 新增能力探测断言

### M3 · 子文件粒度提交（hunk / 行）
- native `git apply --cached --unidiff-zero`（从 diff 生成 patch，按 hunk/行选择）
- UI：diff 视图每行加勾选位；工具栏补 `Stage/Unstage/Revert Hunk`
- 双区视图：`Changes`（未暂存）与 `Staged` 分开显示（此时才真正引入"暂存区模式"）

> ✅ **已完成**（2026-09-23）：见 `docs/开发文档-077-M3-hunk级部分提交（双区差异与块级暂存）.md`。
> 三处与规划不同，都是有意的：
> - **没走 `git apply --cached`**，改成「合成文本 → `writeBlob` → `updateIndex`」自研实现
>   （不依赖本机 git、可单测；`caps.partialStaging` 保留给以后真要换实现时门控）；
> - **只到 hunk，不到行**（行级要再做一层"hunk 内挑行"UI）；
> - 双区不是左右两栏，而是**同文件两块上下并排**（各挂各的按钮）；跨文件的多选视图仍按文件聚合。

### M4 · 分支工作流 + 冲突解决
- 统一操作状态机：`NORMAL / MERGING / REBASING / CHERRY_PICKING / REVERTING`
- 冲突面板（文件列表 + Yours/Theirs/Result 三方）+ `继续 / 跳过 / 终止`
- Pull 策略：Merge / Rebase / FF-only；Push 用 `--force-with-lease`

> ✅ **已完成（第一批）**（2026-09-23）：见 `docs/开发文档-078-M4-分支工作流与冲突解决.md`。
> 状态机 + merge/rebase + 冲突解决窗口（continue/skip/abort）+ 分支行 `⋯` 菜单（从它新建/合并/变基/改名/删除）
> 全部走原生 git。**没做完的**：冲突窗口还是"选一侧"，不是三栏可编辑合并器；
> Pull 策略（Merge/Rebase/FF-only）与 `--force-with-lease` 还没做（原 Pull 仍是 fetch + ff）。

### M5 · IDE 增值
Before Commit（lint/format/test + 结果面板，与 Hooks 同一套）→ Local History（AI checkpoint）→
Git Log 三栏（Branches Pane）→ 工具行收 `⋮ More` → 高级 Git（interactive rebase / reset / worktree / submodule / multi-root / signing）

## 5. 需要拍板的三件事

1. **后端策略**：`native 优先 + isomorphic 兜底`（我推荐，无 git 环境也能降级）／ 全面 native ／ 暂不动
2. **M1 范围**：只做「命名分组 + 活动列表 + 修误 unstage」／ 直接连「Staged 只读视图」一起做
3. **是否接受"IDE 依赖本机 git 可执行文件"**（评测里 PyCharm 也是要求配置 Git executable；差别只是我们允许降级）
